param([string]$InputFile,
      [string]$ProjectToAdd)
Write-Output $InputFile
dotnet sln $InputFile add $ProjectToAdd
.\slnConfigConverter.ps1 -InputFile $InputFile