using System;
using System.Reflection;
using System.Collections;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;

namespace Microsoft.Test.Layout {
    internal class FlowDocumentPageW: ReflectionHelper {
        public FlowDocumentPageW(object flowDocumentPage):
            base(flowDocumentPage, "MS.Internal.PtsHost.FlowDocumentPage")
        {
        }
        
        public int FormattedLinesCount { 
            get { return (int)GetProperty("FormattedLinesCount"); } 
        }          
        
        public ColumnResultListW GetColumnResults() {
            return new ColumnResultListW((IEnumerable)CallMethod("GetColumnResults"));
        }
    }
}