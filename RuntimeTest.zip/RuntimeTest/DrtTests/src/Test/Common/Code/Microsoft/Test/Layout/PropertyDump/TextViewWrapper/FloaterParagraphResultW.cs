using System;
using System.Collections;
using System.Windows.Documents;

namespace Microsoft.Test.Layout {
    internal class FloaterParagraphResultW: ParagraphResultW {
        public FloaterParagraphResultW(object floaterParagraphResult):
            base(floaterParagraphResult, "MS.Internal.Documents.FloaterParagraphResult")
        {
        }
        
        public ParagraphResultListW Paragraphs { 
            get { 
                return new ParagraphResultListW((IEnumerable)GetProperty("FloatingElements"));
            }
        }

        public ColumnResultListW Columns
        {
            get
            {
                return new ColumnResultListW((IEnumerable)GetProperty("Columns"));
            }
        }
    }   
}