using System;

namespace Microsoft.Test.Graphics.TestTypes
{
    /// <summary>
    /// Base class for all testers
    /// </summary>
    internal abstract class GraphicsTestLoader
    {
        /// <summary/>
        public GraphicsTestLoader(TokenList tokens)
        {
            this.tokens = tokens;
        }

        /// <summary/>
        public abstract bool RunMyTests();

        /// <summary/>
        public static bool IsRunAll = false;

        /// <summary/>
        protected TokenList tokens;
    }
}
