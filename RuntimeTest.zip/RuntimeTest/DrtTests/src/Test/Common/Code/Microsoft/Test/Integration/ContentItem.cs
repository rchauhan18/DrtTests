using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Markup;
using System.ComponentModel;

namespace Microsoft.Test.Integration
{
    /// <summary>
    /// 
    /// </summary>
    [ContentProperty("Content")]    
	public class ContentItem : TestContract
	{
        /// <summary>
        /// 
        /// </summary>        
        public object Content
        {
            get
            {
                return _content;
            }
            set
            {
                _content = value;
            }
        }

        object _content = null;
	}
}
