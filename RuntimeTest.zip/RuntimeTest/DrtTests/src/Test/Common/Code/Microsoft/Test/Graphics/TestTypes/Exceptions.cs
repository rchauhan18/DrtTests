using System;

namespace Microsoft.Test.Graphics.TestTypes
{
    /// <summary>
    /// Special Exceptions for CoreGraphics Framework
    /// </summary>
    internal class InvalidScriptFileException : Exception
    {
        /// <summary/>
        public InvalidScriptFileException(string message)
            : base(message)
        {
        }

        /// <summary/>
        public InvalidScriptFileException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
