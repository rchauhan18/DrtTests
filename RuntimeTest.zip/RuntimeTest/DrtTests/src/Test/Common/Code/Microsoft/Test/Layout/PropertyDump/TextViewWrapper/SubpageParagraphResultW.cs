using System;
using System.Collections;
using System.Reflection;
using System.Windows.Documents;

namespace Microsoft.Test.Layout {
    internal class SubpageParagraphResultW : ParagraphResultW
    {
        public SubpageParagraphResultW(object subpageParagraphResult):
            base(subpageParagraphResult, "MS.Internal.Documents.SubpageParagraphResult")
        {
        }
        
        public ColumnResultListW Columns { 
            get { 
                IEnumerable columns = (IEnumerable)GetProperty("Columns");
                return (columns == null) ? null : new ColumnResultListW(columns);
            }
        }
    }   
}