using System.Resources;

[assembly: NeutralResourcesLanguage("en-US")]